# elastography-dynamic-programming

## Source Code written in Matlab

## Based on resources available at: https://users.encs.concordia.ca/~hrivaz/Ultrasound_Elastography/

### Paper implemented: Rivaz, H., Boctor, E., Foroughi, P., Zellars, R., Fichtinger, G., Hager, G., Ultrasound Elastography: a Dynamic Programming Approach, IEEE Trans. Medical Imaging Oct. 2008, vol. 27 pp 1373-1377

#### Implemented by: Cesar Cipelli and Jamil Chowdhury.

Class project done for Concordia University ELEC6661 - Medical Image Processing - Professor Dr. H. Rivaz.